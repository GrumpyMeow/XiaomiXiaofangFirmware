//
//  PatternThree.h
//  SimpleConfig
//
//  Created by Realsil on 14/11/12.
//  Copyright (c) 2014年 Realtek. All rights reserved.
//

#import "PatternBase.h"


@interface PatternThree : PatternBase
{
@private
    unsigned char m_rand[4];
}

@end
