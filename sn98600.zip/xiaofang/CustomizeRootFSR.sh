#!/bin/sh

# This script will generate a flashable firmware using the extracted ROOTFS-R from the original firmware.
# The ROOTFS-R is enlarged to allow more tools.

cd /root/buildscript/

# Configure for device
make sn98660_402mhz_sf_defconfig

# Do a make and make install so that everything is configured. But delete generated output afterwards.
make
make install
rm /root/image/* -f -r

#
make menuconfig

# * Flash Layout and firmware/_f setting -->
# * 	Uboot Partition Size -->
# * 		deselect both options
# * 	NVRAM Partion --> deselect
# * 	Kernel Partition --> 
# * 		deslect options 
# * 	Root File System Partition --> 
# * 		Put Rootfs into FIRMWARE.bin --> select
# * 		Put Rootfs into FIRMWARE_F.bin --> deselect
# * 		Root file system partition --> 224	(7MB)	increase to 	256  (x 32KB = 8MB)
# * 	Rescue System Partition --> deselect
# * 	Configure File Partition --> select erase FIRMWARE.bin, deselect erase FIRMWARE_F.bin
# Exit and save configuration

# Mount original cramfs filesystem
mkdir -p /media/rootfs.org
mount -t cramfs -o loop /root/xiaofang/rootfs.cramfs /media/rootfs.org

# Duplicate original contents to a new directory
mkdir /media/rootfs.new
find /media/rootfs.org > /tmp/filelist.txt
cat /tmp/filelist.txt | cpio -pdm /media/rootfs.new

# Make changes to the filesystem in /media/rootfs.new
pause

mkdir -p /root/image

# Create rootfs.cramfs from directory
/root/toolchain/crosstool-4.5.2/bin/mkcramfs /media/rootfs.new/media/rootfs.new/ /root/image/rootfs.cramfs
make rootfsimage

# Place the original kernel (needed to satify the tools)
cp /root/xiaofang/uImage /root/image/
make kernelimage

make u-boot-2011-09

make firmware
